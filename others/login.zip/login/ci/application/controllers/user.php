<?php

class User extends CI_Controller{
  public function login(){
		$this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[3]');
		// $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|min_length[3]|matches[password]');

		if($this->form_validation->run() == FALSE){
			$data = array(
        'errors' => validation_errors(),
      );
      $this->session->set_flashdata($data);
      redirect('home/');

		}else{

			$username = $this->input->post('username');
			$password = $this->input->post('password');

			// Calling model function 
			$name = $this->user_model->login_user($username, $password);

			if($name){
        
        $user_data = array(
          'name' => $name,
          'username' => $username,
          'logged_in' => true
        );

        $this->session->set_userdata($user_data);
        $this->session->set_flashdata('login_success', 'You are now logged in');

				$this->load->view('layouts/main');
				// redirect('home/index');

			}else{
        $this->session->set_falshdata('login_failed', 'Sorry you are not logged in');
				redirect('home/');
			}
		}
  }
  
  public function logout(){
		$this->session->sess_destroy();
		redirect('/home/index/');
	}
}

?>
