<?php
class User_Model extends CI_Model{
	public function login_user($username, $password){
		$this->db->where(['userid'=>$username, 'password'=>$password]);
		$result = $this->db->get('users');
		if($result->num_rows() == 1){
			return $result->row(0)->name;
		}else{
			return false;
		}
	}
}
?>
