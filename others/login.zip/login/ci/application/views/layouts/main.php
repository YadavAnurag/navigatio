<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Login</title>
	<link rel="stylesheet" href="<?php echo(base_url());?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo(base_url());?>assets/css/style.css">
	<script src="<?php echo (base_url());?>assets/jquery/jquery.js"></script>
	<script src="<?php echo (base_url());?>assets/js/bootstrap.min.js"></script>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark">
		<a href="#" class="navbar-brand text-white">Navigatio</a>
	</nav>
	<div class="container-fluid">
		<div class="col-lg-4 offset-lg-4 col-md-4 offset-md-4 col-sm-10 offset-sm-1 col-xs-12 pb-5 container-fluid">
			<?php $this->load->view($main_view);?>
		</div>
	</div>
</body>
</html>
