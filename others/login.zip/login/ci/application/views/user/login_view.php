<?php if($this->session->userdata('logged_in')):?>

	<?php echo (form_open('/user/logout'));?>
		<p class="mt-5 text-white pt-5 text-center">
			<?php echo ('You are logged in as ').$this->session->userdata('name');?>
		</p>
		<?php 
			$data = array(
				'class'=> 'btn btn-primary form-control mt-2 p-1 text-white',
				'name' => 'submit',
				'value' => 'Logout'
			);
		?>
		<?php echo (form_submit($data));?>
  <?php echo (form_close());?>

<?php else:?>

<?php
	$attributes = array(
    'id'=>'login_form',
    'class' => 'mt-5 text-center pt-5 p-1'
  );
?>

<?php if($this->session->flashdata('errors')):?>
<?php echo ($this->session->flashdata('errors'));?>
<?php endif;?>

<?php echo (form_open('user/login', $attributes));?>
  <h3>Login Here</h3>
  <div class="form-group p-1">
    <?php $data = array('class'=>'form_label');?>
    <!-- <?php echo(form_label('User Name'));?> -->
    <?php 
      $data = array(
        'class' => 'form-control mt-4 text-center',
        'name' => 'username',
        'placeholder' => 'Enter your username'
      );
    ?>
    <?php echo (form_input($data));?>
  </div>

  <div class="form-group pl-1 pr-1">
    <?php $data = array('class'=>'form_label');?>
    <!-- <?php echo(form_label('Password'));?> -->
    <?php 
      $data = array(
        'class' => 'form-control  text-center',
        'name' => 'password',
        'placeholder' => 'Enter your password'
      );
    ?>
    <?php echo (form_password($data));?>
  </div>

  <div class="form-group p-1">
    <?php 
      $data = array(
        'class' => 'btn btn-primary form-control mt-2 p-1 text-white',
        'name' => 'submit',
        'value' => 'Submit'
      );
    ?>
    <?php echo (form_submit($data));?>
  </div>
<?php echo (form_close());?>
<?php endif;?>
