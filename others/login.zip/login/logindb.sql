DROP DATABASE logindb;
CREATE DATABASE logindb;
USE logindb;

CREATE TABLE users(
	id INT UNSIGNED NOT NULL auto_increment,
	userid VARCHAR(100) NOT NULL,
	name VARCHAR(100) NOT NULL,
	password VARCHAR(100) NOT NULL,
	PRIMARY KEY (id)
	);
INSERT INTO users(userid, name, password)VALUES
	('shweta', 'Shweta Pandey', 'shweta'),
	('anu', 'Anu Mishra','anu'),
	('tanu', 'Tanu Tiwari', 'tanu');